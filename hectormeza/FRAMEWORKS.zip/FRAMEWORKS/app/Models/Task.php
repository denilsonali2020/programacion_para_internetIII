<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $table = 'tareas';

    protected $fillable = ['titulo'];

    public $timestamps = false;
}
