<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    
    public function index()
    {
        return Task::orderBy('id', 'desc')->get();
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
        ]);

        return Task::create(['titulo' => $validated['title']]);
    }

    public function destroy($id)
    {
        Task::destroy($id);
        return response()->json(['ok' => true]);
    }
}
