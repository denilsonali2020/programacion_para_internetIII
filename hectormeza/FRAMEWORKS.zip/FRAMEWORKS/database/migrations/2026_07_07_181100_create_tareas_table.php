<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// NOTE: The table name 'tareas' and column 'titulo' are kept in Spanish
// on purpose, because the assignment explicitly requires a table called
// "tareas" with fields "id" and "titulo".
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tareas', function (Blueprint $table) {
            $table->id();
            $table->string('titulo');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tareas');
    }
};
